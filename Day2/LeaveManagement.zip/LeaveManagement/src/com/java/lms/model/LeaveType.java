package com.java.lms.model;

public enum LeaveType {
	EL, PL, ML
}
