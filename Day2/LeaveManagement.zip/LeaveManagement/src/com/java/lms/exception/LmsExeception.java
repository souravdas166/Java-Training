package com.java.lms.exception;

public class LmsExeception extends Exception{
	public LmsExeception(String error) {
		super(error);
	}
}
